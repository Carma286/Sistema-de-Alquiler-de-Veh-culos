/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alquiler;

/**
 *
 * @author EMANUEL
 */
public  class auto extends vehiculo {
    public auto(String marca,String modelo,double tarifabase){
    super(marca,modelo,tarifabase);}

    @Override
    public double calcularcostodealquiler(int dias) {
        return getTarifabase()*dias;
    }
    
}
