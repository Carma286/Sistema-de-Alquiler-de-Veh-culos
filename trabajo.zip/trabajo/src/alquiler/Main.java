/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package alquiler;

/**
 *
 * @author EMANUEL
 */
public class Main {
      
    public static void main(String[] args) {
        String marca="toyota";
        String modelo="corolla";
        double tarifa= 50;
        int dia = 5;
        
        vehiculo auto1= new auto(marca, modelo,tarifa);
          System.out.println("marca " + auto1.getMarca()); 
          System.out.println("modelo " + auto1.getModelo());
          System.out.println("tarifa por dia" + auto1.getTarifabase());
          System.out.println("dias"+ dia);
          System.out.println("costo total" + auto1.calcularcostodealquiler(dia));
    }
    
}
